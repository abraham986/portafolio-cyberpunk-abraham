# Portafolio Profesional Cyberpunk

Proyecto académico: portafolio profesional para un perfil de **estudiante de Ingeniería en Sistemas, con interés en desarrollo Full-Stack e inteligencia artificial**, desarrollado con HTML5, CSS3, JavaScript y Bootstrap 5.

## Características

- Diseño responsivo con enfoque mobile-first.
- Estética Cyberpunk en modo oscuro con acentos neón.
- Navbar flotante con navegación por secciones.
- Hero con presentación y espacio para fotografía.
- Sección de perfil / biografía.
- Stack tecnológico en tarjetas con efecto neón al pasar el cursor.
- Galería de proyectos con filtros interactivos hechos con JavaScript.
- Footer con enlaces sociales.
- Botón «Volver arriba».
- Año del footer actualizado automáticamente.

## Tecnologías utilizadas

- HTML5
- CSS3
- JavaScript
- Bootstrap 5.3.3
- Bootstrap Icons
- Google Fonts: Orbitron y Rajdhani

## Estructura del proyecto

```text
mi-portafolio/
├── index.html
├── css/
│   └── styles.css
├── js/
│   └── script.js
├── img/
│   └── perfil.jpg
└── README.md
```

## Cómo ejecutarlo localmente

1. Descarga o clona este repositorio.
2. Abre la carpeta del proyecto en Visual Studio Code.
3. Abre `index.html` en tu navegador. También puedes utilizar la extensión Live Server.
4. Para personalizarlo, revisa los datos de ejemplo en `index.html`.

## Personalización antes de entregar

- Cambia «Abrahan Familia Agramonte» por tu nombre.
- Actualiza el título profesional y la biografía con información verdadera sobre ti.
- Sustituye el espacio de fotografía por tu imagen. Puedes guardar la foto como `img/perfil.png` y reemplazar el bloque `.portrait-placeholder` por:

- Actualiza los enlaces de GitHub, LinkedIn, X y correo electrónico.
- Sustituye los proyectos de demostración por proyectos propios o académicos. No presentes proyectos ficticios como trabajos reales.
- Ajusta tecnologías y estadísticas a tu experiencia real.

## Publicación en GitHub Pages

1. Crea una cuenta en https://github.com/ si todavía no tienes una.
2. Crea un repositorio nuevo y público, por ejemplo `mi-portafolio-cyberpunk`.
3. Sube todos los archivos y carpetas manteniendo la estructura.
4. En el repositorio, entra en **Settings → Pages**.
5. En **Build and deployment**, selecciona **Deploy from a branch**.
6. Selecciona la rama `main` y la carpeta `/ (root)`, luego pulsa **Save**.
7. Espera a que GitHub Pages publique el sitio. La URL normalmente tendrá esta forma:
   `https://TU-USUARIO.github.io/mi-portafolio-cyberpunk/`

## Blog / documentación del proyecto

Este README funciona como documentación técnica del proyecto. Para cumplir el requisito de publicar un blog o documentación, puedes mantener esta documentación en el repositorio y, si el profesor requiere una página de documentación independiente, crear una sección adicional en GitHub Pages.

## Autor

Abrahan Familia Agramonte — Estudiante de Ingeniería en Sistemas.
