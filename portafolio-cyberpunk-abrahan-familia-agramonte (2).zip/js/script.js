// Interactividad del portafolio Cyberpunk
document.addEventListener("DOMContentLoaded", () => {
  // Año automático en el footer
  const yearElement = document.getElementById("currentYear");
  if (yearElement) yearElement.textContent = new Date().getFullYear();

  // Filtros interactivos de proyectos
  const filterButtons = document.querySelectorAll(".filter-btn");
  const projectItems = document.querySelectorAll(".project-item");
  const emptyMessage = document.getElementById("filterEmpty");

  filterButtons.forEach((button) => {
    button.addEventListener("click", () => {
      const selectedFilter = button.dataset.filter;

      filterButtons.forEach((item) => {
        const isActive = item === button;
        item.classList.toggle("active", isActive);
        item.setAttribute("aria-pressed", String(isActive));
      });

      let visibleCount = 0;
      projectItems.forEach((project) => {
        const matches = selectedFilter === "all" || project.dataset.category === selectedFilter;
        project.classList.toggle("is-hidden", !matches);
        if (matches) visibleCount++;
      });

      if (emptyMessage) emptyMessage.classList.toggle("d-none", visibleCount !== 0);
    });
  });

  // Botón Volver Arriba: aparece al desplazarse
  const backToTop = document.getElementById("backToTop");
  const toggleBackToTop = () => {
    if (backToTop) backToTop.classList.toggle("show", window.scrollY > 350);
  };
  window.addEventListener("scroll", toggleBackToTop, { passive: true });
  toggleBackToTop();

  if (backToTop) {
    backToTop.addEventListener("click", () => {
      window.scrollTo({ top: 0, behavior: "smooth" });
    });
  }

  // Cierra el menú móvil después de seleccionar una sección
  const navLinks = document.querySelectorAll(".navbar-nav .nav-link");
  const navCollapse = document.getElementById("mainNav");
  navLinks.forEach((link) => {
    link.addEventListener("click", () => {
      if (navCollapse && navCollapse.classList.contains("show") && window.bootstrap) {
        window.bootstrap.Collapse.getOrCreateInstance(navCollapse).hide();
      }
    });
  });
});
